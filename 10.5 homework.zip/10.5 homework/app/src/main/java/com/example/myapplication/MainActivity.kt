package com.example.myapplication

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView
import android.widget.Toast
import android.widget.Button as Button

class MainActivity : AppCompatActivity() {

    var code: String = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val written_code: TextView = findViewById(R.id.written_code)
        written_code.setText(code)

        val button1: Button = findViewById(R.id.button1)
        button1.setOnClickListener { it ->
            written_code.append("1")
        }

        val button2: Button = findViewById(R.id.button2)
        button2.setOnClickListener { it ->
            written_code.append("2")
        }
        val button3: Button = findViewById(R.id.button3)
        button3.setOnClickListener { it ->
            written_code.append("3")
        }
        val button4: Button = findViewById(R.id.button4)
        button4.setOnClickListener { it ->
            written_code.append("4")
        }
        val button5: Button = findViewById(R.id.button5)
        button5.setOnClickListener { it ->
            written_code.append("5")
        }
        val button6: Button = findViewById(R.id.button6)
        button6.setOnClickListener { it ->
            written_code.append("6")
        }
        val button7: Button = findViewById(R.id.button7)
        button7.setOnClickListener { it ->
            written_code.append("7")
        }

        val button8: Button = findViewById(R.id.button8)
        button8.setOnClickListener { it ->
            written_code.append("8")
        }
        val button9: Button = findViewById(R.id.button9)
        button9.setOnClickListener { it ->
            written_code.append("9")
        }
        val button_back: Button = findViewById(R.id.back)
        button_back.setOnClickListener { it ->
            val asd = written_code.getText().toString().dropLast(1)
            written_code.setText(asd)
        }
        val button0: Button = findViewById(R.id.button0)
        button0.setOnClickListener { it ->
            written_code.append("0")
        }
        val buttonOk: Button = findViewById(R.id.OK)
        buttonOk.setOnClickListener { it ->
            var isSame: Boolean = false
            if(written_code.getText().toString().contains("1567")){ isSame = true }
            if(isSame==true){Toast.makeText(this, "Toast", Toast.LENGTH_SHORT ).show()}

        }
    }
}